//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

//: Ajude o velho Ulisses a chegar em casa
//: ---
//: Atribua a variável abaixo a idade do velho Ulisses
import UIKit
import PlaygroundSupport
import CoreLocation

let view = UIView()
view.backgroundColor = .blue
view.frame = CGRect(x: 0, y: 0, width: 100, height: 100)


PlaygroundPage.current.liveView = view


//let idade = /*#-editable-code*/<##T#Idade##Int#>/*#-end-editable-code*/
//let idade = <#T##idade#image#>
//let image =     /*#-editable-code*/<##T#Idade##Int#>/*#-end-editable-code*/
    
//    UIImage(name:/*#-editable-code*/UIImage/*#-end-editable-code*/)


var txtField: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 50, height: 50));
txtField.backgroundColor = .red

view.addSubview(txtField)


//if (CLLocationManager.locationServicesEnabled())
//{
//    self.locationManager = CLLocationManager()
//    locationManager.requestWhenInUseAuthorization()
//    self.locationManager.delegate = self
//    self.locationManager.distanceFilter = kCLDistanceFilterNone
//    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
//    self.locationManager.startUpdatingLocation()
//
//    //            locationManager = CLLocationManager()
//    //            locationManager.delegate = self
//    //            locationManager.desiredAccuracy = kCLLocationAccuracyBest
//    //            locationManager.requestAlwaysAuthorization()
//    //            locationManager.startUpdatingLocation()
//}


//let path = NSBundle.mainBundle().pathForResource("logo", ofType: "png")
//let img = UIImage(contentsOfFile:path)

txtField.text="xuxa"


let label = UILabel()
label.backgroundColor = .cyan
label.text = "The Live View"

view.addSubview(label)

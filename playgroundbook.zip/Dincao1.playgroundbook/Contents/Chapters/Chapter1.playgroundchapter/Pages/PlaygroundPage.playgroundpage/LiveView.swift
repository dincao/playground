import UIKit
import PlaygroundSupport

let view = UIView()
view.backgroundColor = .blue
view.frame = CGRect(x: 0, y: 0, width: 100, height: 100)


PlaygroundPage.current.liveView = view

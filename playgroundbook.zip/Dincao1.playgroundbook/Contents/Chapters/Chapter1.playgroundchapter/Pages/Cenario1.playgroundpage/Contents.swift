/*:
 # 2ª Guerra Mundial - Inicio
 A Segunda Guerra Mundial foi um conflito militar global que durou de [?????] a [?????], envolvendo a maioria das nações do mundo.
 ## Variáveis
 Uma variável é um espaço na memória do computador destinado a um dado que é alterado durante a execução do algoritmo. Para funcionar corretamente, as variáveis precisam ser definidas por nomes e tipos. Veja os diferentes tipos de dados:
 
 ## Atividade
 Crie as variáveis necessárias para armazenar o ano de inicio e término da 2ª Guerra Mundial.
 
 ## Resolução
 */
//#-editable-code Digite seu código aqui

//#-end-editable-code

/*:
 [Próximo](@next)
 */


/*:
 # 2ª Guerra Mundial - Nações
 A Segunda Guerra Mundial envolveu a maioria das nações do mundo — incluindo todas as grandes potências — organizadas em duas alianças militares opostas: os Aliados e o Eixo.
 ## Vetores
 Um vetor é uma coleção de variáveis de mesmo tipo, acessíveis com um único nome e armazenados contiguamente na memória.
 
 ## Atividade
 Crie dois vetores que representem os eixos de nações da 2ª Guerra Mundial.
 Preencha com o respectivo nome dos países.
 
 ## Resolução
 */
//#-editable-code Digite seu código aqui

//#-end-editable-code




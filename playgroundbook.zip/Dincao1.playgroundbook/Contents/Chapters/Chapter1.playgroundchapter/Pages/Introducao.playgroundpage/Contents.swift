/*:
 # Introdução
 
 **Exemplo de Playground InterDisciplinar - VISÃO ALUNO
 
 ![Dollar bill](teste.png)
 
 Esse PlayGround faz a integração de disciplinas de Humanas com os conecitos de programação.
 
 ## O que farei ?
 Com base nos eventos apresentados a direita da página, resolva através de algoritmos.
 
 **Divirta-se.**
 
 [Começar](@next)
 
 
 */

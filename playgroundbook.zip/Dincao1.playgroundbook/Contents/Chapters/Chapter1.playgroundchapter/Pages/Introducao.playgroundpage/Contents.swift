/*:
 # Introdução
 
 **Pesquise e descreva resumidamente o que foi a 2ª Guerra Mundial
 
 ![Dollar bill](introducao.png)
 
 Esse PlayGround faz a integração de disciplina de História com conceitos de programação.
 
 ## O que farei ?
 Com base nos eventos apresentados a direita da página, resolva através de algoritmos.
 
 **Divirta-se.**
 
 [Começar](@next)
  
 */
